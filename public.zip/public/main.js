const socket = io();

const clientsTotal = document.getElementById('client-total')

const messageContainer = document.getElementById('message-conatainer')

const nameInput = document.getElementById('user-name')
const messageForm = document.getElementById('message-form')
const messageInput = document.getElementById('message-input')

const messageTone = new Audio('/message-tone.mp3')

messageForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    sendMessage()
})

socket.on('clients-total', (data)=>{
    clientsTotal.innerText = `Total Clients: ${data}`
})

function sendMessage(){
    if(messageInput.value == '') return
    console.log(messageInput.value)
    const data = {
        name : nameInput.value,
        message: messageInput.value,
        dateTime: new Date()
    }

    socket.emit('message', data)
    addMessageToUI(true, data)
    messageInput.value = ''
}

socket.on('chat-message', (data)=>{
    //console.log(data)
    messageTone.play()
    addMessageToUI(false, data)
})

function addMessageToUI( isOwnMessage, data){
    clearFeedback()
    const element = `
    <li class="${isOwnMessage? "user-message" : "client-message"}">
    <p class="message" id="message">
          ${data.message}
        <span>${data.name} 🕛 ${moment(data.dateTime).fromNow()}</span>
    </p>
    
</li>`

messageContainer.innerHTML += element

scrollToBottom()
}

function scrollToBottom(){
    messageContainer.scrollTo(0, messageContainer.scrollHeight)
}

messageInput.addEventListener('focus', (e)=>{
    socket.emit('feedback', {
        feedback: `✍️ ${nameInput.value} is typing a message`
    })
})

messageInput.addEventListener('keypress', (e)=>{
    socket.emit('feedback', {
        feedback: `✍️ ${nameInput.value} is typing a message`
    })
})

messageInput.addEventListener('blur', (e)=>{
    socket.emit('feedback', {
        feedback: ``
    })
})

socket.on('feedback', (data) =>{
    clearFeedback()
    const element = `
    <li class="typing-indicator">
    <p class="indicator" id="indicator">${data.feedback}</p>
</li>`

messageContainer.innerHTML += element
})

function clearFeedback(){
    document.querySelectorAll('li.typing-indicator').forEach(element =>{
        element.parentNode.removeChild(element)
    })
}